<?php 
$OC_Version = array(13,0,1,1);
$OC_VersionString = '13.0.1';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '12.0' => true,
    '13.0' => true,
  ),
  'owncloud' => 
  array (
  ),
);
$OC_Build = '2018-03-13T18:49:57+00:00 c2cea293d54bbbdf908346cdf3acc2a545142ba1';
$vendor = 'nextcloud';
